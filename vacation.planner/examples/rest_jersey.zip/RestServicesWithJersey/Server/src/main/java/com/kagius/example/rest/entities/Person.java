package com.kagius.example.rest.entities;

public interface Person {

    String getName();
    String getSurname();
    String getCode();
}
